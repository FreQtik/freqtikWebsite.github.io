# Third-Party Notices

Master Desktop Tap is created by FreQtik and built with JUCE 8.

## JUCE

JUCE framework: https://juce.com/
JUCE 8 licence: https://juce.com/legal/juce-8-licence/
JUCE source/license information: https://github.com/juce-framework/JUCE/blob/master/LICENSE.md

FreQtik distributes this compiled binary-only freeware/public-beta utility under the JUCE 8 Starter Licence route, based on the licence selected in the JUCE account used by FreQtik. The JUCE framework remains owned and licensed separately by Raw Material Software Limited / JUCE.

This release package does not include the JUCE framework source code. End users only need the compiled VST3 bundle.

## VST3

The VST3 format support is provided through JUCE's VST3 integration and the Steinberg VST3 SDK licensing as handled by JUCE.

VST is a trademark of Steinberg Media Technologies GmbH.
