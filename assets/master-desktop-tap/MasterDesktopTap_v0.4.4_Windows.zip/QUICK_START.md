Master Desktop Tap v0.4.5 Public Beta

Free Windows VST3 utility for routing ASIO DAW master audio into Discord / OBS / Windows desktop streaming.

INSTALL:
Copy the whole folder:

  VST3\Master Desktop Tap.vst3

into:

  C:\Program Files\Common Files\VST3\

Then rescan VST3 plugins in your DAW.

BASIC USE:
1. Insert Master Desktop Tap last on your DAW master/stereo out.
2. Select a normal shared Windows Audio output device.
3. Press STREAM MODE.
4. Start Discord/OBS screen share with audio enabled.
5. Before normal production/export, press SAFE PRODUCTION or bypass/remove the plugin.

Good defaults: Stream Gain -12 dB, Buffer 100 ms, Safety Clip Limiter ON.

